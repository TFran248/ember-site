# Ember — the daily merge puzzle

A 2048-style merge game with a streak multiplier: chain merges on consecutive
moves to build up to ×4 points; one dry move resets the flame. Includes a
Wordle-style daily mode (same seeded board for every player worldwide) and a
shareable emoji score card.

## Run locally

```bash
npm install
npm run dev        # http://localhost:5173
```

## Deploy (free)

**Vercel:** push this folder to a GitHub repo → vercel.com → "Import Project"
→ accept defaults (Vite is auto-detected) → done. Add your custom domain in
project settings.

**Netlify:** drag-and-drop the `dist/` folder after `npm run build`, or connect
the repo. Build command `npm run build`, publish directory `dist`.

## Before launch — a 5-minute checklist

1. **Set the launch date.** In `src/App.jsx`, change `LAUNCH_DAY` to your real
   launch date so "Daily #1" lands on day one:
   `Date.UTC(2026, 6, 13)` = July 13, 2026 (months are 0-indexed).
2. **Own the copyright notice.** Replace "© 2026" in `src/App.jsx` with your
   name or company.
3. **Share URL is automatic** — the score card appends `window.location.origin`,
   so it always points at whatever domain you deploy to.

## What persists

Best score and theme choice are saved to `localStorage` (guarded for private
browsing). Everything else is per-session by design.

## Phase 2 ideas (when traction justifies it)

- Server-validated daily leaderboard (the seeded RNG makes replay-verification
  possible: store the move list, re-simulate server-side to verify scores).
- Gate PRO themes behind a one-time purchase (Stripe Payment Links are the
  fastest path — no backend needed).
- Capacitor wrap for App Store / Play Store distribution.

## License

All rights reserved. The game logic was fuzz-tested across 2,000 simulated
games (235k moves) with invariant checks on tile positions, value conservation,
and merge accounting.
