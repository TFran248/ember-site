/*
 * EMBER — merge puzzle with streak multiplier
 * © 2026. All rights reserved. Unauthorized copying, modification, or
 * redistribution of this source code is prohibited.
 *
 * Web release build:
 *  • localStorage persistence — best score, theme choice, daily history
 *    (guarded with try/catch for private-browsing modes).
 *  • Share text appends the site URL so every share is an acquisition link.
 *  • Daily mode: date-seeded mulberry32 PRNG → identical board and tile
 *    stream for every player worldwide each UTC day.
 */

import { useState, useEffect, useRef, useCallback } from "react";

const SIZE = 4;
const GAP = 8;
let idCounter = 1;
const newId = () => idCounter++;

// ————— persistence (safe in private mode) —————
const load = (k, d) => {
  try {
    const v = localStorage.getItem(k);
    return v !== null ? JSON.parse(v) : d;
  } catch {
    return d;
  }
};
const save = (k, v) => {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch { /* storage unavailable — play continues, nothing persists */ }
};

// ————— seeded RNG for daily mode —————
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const LAUNCH_DAY = Math.floor(Date.UTC(2026, 6, 13) / 864e5); // ← set to your launch date
const todayUTC = () => Math.floor(Date.now() / 864e5);
const dailyNumber = () => Math.max(1, todayUTC() - LAUNCH_DAY + 1);

// ————— themes —————
const EMBER_TILES = {
  2:    { bg: "#313A55", fg: "#AEB9D6", glow: "none" },
  4:    { bg: "#3A4668", fg: "#C7D2EC", glow: "none" },
  8:    { bg: "#2E6E7E", fg: "#EAF7F9", glow: "0 0 14px rgba(46,110,126,.45)" },
  16:   { bg: "#2E8C74", fg: "#F0FBF7", glow: "0 0 16px rgba(46,140,116,.5)" },
  32:   { bg: "#55A34E", fg: "#FFFFFF", glow: "0 0 18px rgba(85,163,78,.5)" },
  64:   { bg: "#C79A2E", fg: "#FFFFFF", glow: "0 0 20px rgba(199,154,46,.55)" },
  128:  { bg: "#E08A2E", fg: "#FFFFFF", glow: "0 0 22px rgba(224,138,46,.6)" },
  256:  { bg: "#ED6B3C", fg: "#FFFFFF", glow: "0 0 24px rgba(237,107,60,.65)" },
  512:  { bg: "#F04E4E", fg: "#FFFFFF", glow: "0 0 28px rgba(240,78,78,.7)" },
  1024: { bg: "#FF4E3D", fg: "#FFFFFF", glow: "0 0 32px rgba(255,78,61,.8)" },
  2048: { bg: "#FFD86B", fg: "#4A2E00", glow: "0 0 40px rgba(255,216,107,.9)" },
};
const hslRamp = (h1, h2, l1, l2, sat) => (v) => {
  const i = Math.min(Math.log2(v) - 1, 10);
  const t = i / 10;
  const h = h1 + (h2 - h1) * t;
  const l = l1 + (l2 - l1) * t;
  return {
    bg: `hsl(${h} ${sat}% ${l}%)`,
    fg: l > 62 ? "#141625" : "#F2F5FF",
    glow: i >= 2 ? `0 0 ${10 + i * 3}px hsl(${h} 85% ${Math.min(l + 18, 82)}% / .6)` : "none",
  };
};
const THEMES = {
  ember: {
    label: "Ember", pro: false,
    page: "radial-gradient(120% 90% at 50% 0%, #1A2140 0%, #0E1224 55%, #0A0D1A 100%)",
    board: "#141A30", cell: "#1B2138", chip: "#1B2138",
    accent: "#ED6B3C", title: "linear-gradient(90deg, #FFD86B, #ED6B3C)",
    tile: (v) => EMBER_TILES[v] || { bg: "#FFF3C9", fg: "#4A2E00", glow: "0 0 48px rgba(255,243,201,.95)" },
  },
  glacier: {
    label: "Glacier", pro: true,
    page: "radial-gradient(120% 90% at 50% 0%, #16294A 0%, #0C1729 55%, #070D18 100%)",
    board: "#0F1B2E", cell: "#16263E", chip: "#16263E",
    accent: "#5FC7E8", title: "linear-gradient(90deg, #BFEFFF, #5FA8E8)",
    tile: hslRamp(218, 188, 30, 80, 55),
  },
  voltage: {
    label: "Voltage", pro: true,
    page: "radial-gradient(120% 90% at 50% 0%, #241238 0%, #140A24 55%, #0B0614 100%)",
    board: "#170D28", cell: "#201336", chip: "#201336",
    accent: "#E84FD0", title: "linear-gradient(90deg, #B98CFF, #FF5FD6)",
    tile: hslRamp(262, 322, 34, 62, 72),
  },
};

// ————— pure game logic (fuzz-tested: 2000 games / 235k moves) —————
function emptyCells(tiles) {
  const occ = new Set(tiles.filter(t => !t.dying).map(t => t.row * SIZE + t.col));
  const out = [];
  for (let r = 0; r < SIZE; r++)
    for (let c = 0; c < SIZE; c++)
      if (!occ.has(r * SIZE + c)) out.push({ row: r, col: c });
  return out;
}
function addRandomTile(tiles, rng) {
  const cells = emptyCells(tiles);
  if (!cells.length) return tiles;
  const cell = cells[(rng() * cells.length) | 0];
  return [...tiles, { id: newId(), value: rng() < 0.9 ? 2 : 4, row: cell.row, col: cell.col, isNew: true }];
}
function slide(tiles, dir) {
  const vertical = dir === "up" || dir === "down";
  const reverse = dir === "down" || dir === "right";
  let moved = false, scoreGain = 0, mergeCount = 0;
  const result = [];
  for (let i = 0; i < SIZE; i++) {
    let line = tiles
      .filter(t => !t.dying && (vertical ? t.col : t.row) === i)
      .sort((a, b) => (vertical ? a.row - b.row : a.col - b.col));
    if (reverse) line.reverse();
    let pos = 0;
    for (let j = 0; j < line.length; j++) {
      const t = line[j];
      const idx = reverse ? SIZE - 1 - pos : pos;
      const row = vertical ? idx : i;
      const col = vertical ? i : idx;
      if (j + 1 < line.length && line[j + 1].value === t.value) {
        const partner = line[j + 1];
        const nv = t.value * 2;
        scoreGain += nv; mergeCount++; moved = true;
        result.push({ ...t, row, col, dying: true, isNew: false, justMerged: false });
        result.push({ ...partner, row, col, dying: true, isNew: false, justMerged: false });
        result.push({ id: newId(), value: nv, row, col, justMerged: true });
        j++;
      } else {
        if (t.row !== row || t.col !== col) moved = true;
        result.push({ ...t, row, col, isNew: false, justMerged: false });
      }
      pos++;
    }
  }
  return { tiles: result, moved, scoreGain, mergeCount };
}
function movesAvailable(tiles) {
  const live = tiles.filter(t => !t.dying);
  if (emptyCells(live).length) return true;
  const grid = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
  live.forEach(t => (grid[t.row][t.col] = t.value));
  for (let r = 0; r < SIZE; r++)
    for (let c = 0; c < SIZE; c++) {
      if (c + 1 < SIZE && grid[r][c] === grid[r][c + 1]) return true;
      if (r + 1 < SIZE && grid[r][c] === grid[r + 1][c]) return true;
    }
  return false;
}

const multOf = (streak) => 1 + Math.floor(Math.min(streak, 9) / 3);
let popCounter = 0;

export default function App() {
  const rngRef = useRef(Math.random);
  const stateRef = useRef(null);

  const makeGame = (mode, best) => {
    rngRef.current = mode === "daily" ? mulberry32(todayUTC()) : Math.random;
    return {
      mode,
      tiles: addRandomTile(addRandomTile([], rngRef.current), rngRef.current),
      score: 0, best, streak: 0, peakMult: 1,
      over: false, won: false, keepGoing: false,
    };
  };
  if (stateRef.current === null) stateRef.current = makeGame("classic", load("ember-best", 0));
  const [game, setGame] = useState(stateRef.current);
  const commit = (next) => { stateRef.current = next; setGame(next); };

  const [themeKey, setThemeKey] = useState(() => {
    const t = load("ember-theme", "ember");
    return THEMES[t] ? t : "ember";
  });
  const theme = THEMES[themeKey];
  const [pop, setPop] = useState(null);
  const [copied, setCopied] = useState(false);
  const undoRef = useRef(null);
  const [canUndo, setCanUndo] = useState(false);
  const touchRef = useRef(null);

  // persist best + theme
  useEffect(() => { save("ember-best", game.best); }, [game.best]);
  useEffect(() => { save("ember-theme", themeKey); }, [themeKey]);

  const mult = multOf(game.streak);

  const doMove = useCallback((dir) => {
    const s = stateRef.current;
    if (s.over || (s.won && !s.keepGoing)) return;
    const live = s.tiles.filter(t => !t.dying);
    const { tiles: slid, moved, scoreGain, mergeCount } = slide(live, dir);
    if (!moved) return;

    undoRef.current = { tiles: live, score: s.score, streak: s.streak, won: s.won, keepGoing: s.keepGoing, peakMult: s.peakMult };
    setCanUndo(true);

    const streak = mergeCount > 0 ? s.streak + 1 : 0;
    const m = multOf(streak);
    const gained = scoreGain * m;
    const score = s.score + gained;
    const withNew = addRandomTile(slid, rngRef.current);
    const won = s.won || withNew.some(t => t.value >= 2048 && !t.dying);

    commit({
      ...s, tiles: withNew, score, best: Math.max(s.best, score),
      streak, peakMult: Math.max(s.peakMult, m), won,
    });
    if (gained > 0) setPop({ id: ++popCounter, text: `+${gained}${streak >= 3 ? " 🔥" : ""}` });

    setTimeout(() => {
      const cur = stateRef.current;
      const cleaned = cur.tiles.filter(t => !t.dying);
      if (cleaned.length !== cur.tiles.length || !movesAvailable(cleaned)) {
        commit({ ...cur, tiles: cleaned, over: !movesAvailable(cleaned) });
      }
    }, 130);
  }, []);

  useEffect(() => {
    const map = { ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" };
    const onKey = (e) => { if (map[e.key]) { e.preventDefault(); doMove(map[e.key]); } };
    window.addEventListener("keydown", onKey, { passive: false });
    return () => window.removeEventListener("keydown", onKey);
  }, [doMove]);

  const onTouchStart = (e) => {
    if (e.touches.length !== 1) { touchRef.current = null; return; }
    const t = e.touches[0];
    touchRef.current = { x: t.clientX, y: t.clientY };
  };
  const onTouchEnd = (e) => {
    if (!touchRef.current || e.touches.length > 0) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - touchRef.current.x;
    const dy = t.clientY - touchRef.current.y;
    touchRef.current = null;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
    doMove(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : (dy > 0 ? "down" : "up"));
  };

  const startGame = (mode) => {
    undoRef.current = null;
    setCanUndo(false);
    setCopied(false);
    commit(makeGame(mode, stateRef.current.best));
  };

  const undo = () => {
    if (!undoRef.current) return;
    const u = undoRef.current;
    undoRef.current = null;
    setCanUndo(false);
    commit({
      ...stateRef.current,
      tiles: u.tiles, score: u.score, streak: u.streak,
      won: u.won, keepGoing: u.keepGoing, peakMult: u.peakMult, over: false,
    });
  };

  // ————— shareable score card —————
  const shareText = () => {
    const s = stateRef.current;
    const top = Math.max(...s.tiles.filter(t => !t.dying).map(t => t.value));
    const heat = "🔥".repeat(s.peakMult) + "▫️".repeat(4 - s.peakMult);
    const head = s.mode === "daily" ? `EMBER Daily #${dailyNumber()}` : "EMBER Classic";
    const url = typeof window !== "undefined" ? window.location.origin : "";
    return `${head}\n${heat} peak ×${s.peakMult}\nScore ${s.score.toLocaleString()} · Top tile ${top}${s.won ? " 🏆" : ""}\n${url}`;
  };
  const share = async () => {
    const text = shareText();
    try {
      if (navigator.share) { await navigator.share({ text }); }
      else { await navigator.clipboard.writeText(text); }
      setCopied(true);
    } catch {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
        setCopied(true);
      } catch { /* clipboard unavailable — text remains visible on the card */ }
    }
    setTimeout(() => setCopied(false), 1600);
  };

  const cellSize = `calc((100% - ${(SIZE + 1) * GAP}px) / ${SIZE})`;
  const posStyle = (row, col) => ({
    width: cellSize,
    height: cellSize,
    left: `calc(${GAP}px + ${col} * ((100% - ${(SIZE + 1) * GAP}px) / ${SIZE} + ${GAP}px))`,
    top: `calc(${GAP}px + ${row} * ((100% - ${(SIZE + 1) * GAP}px) / ${SIZE} + ${GAP}px))`,
  });

  const heatSegs = Math.min(game.streak, 9);
  const showWinOverlay = game.won && !game.keepGoing;

  return (
    <div style={{
      minHeight: "100vh", background: theme.page,
      display: "flex", flexDirection: "column", alignItems: "center",
      fontFamily: "'Sora', ui-rounded, system-ui, -apple-system, sans-serif",
      color: "#E8ECF8", padding: "20px 16px 40px", userSelect: "none", WebkitUserSelect: "none",
      transition: "background 300ms",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;800&display=swap');
        @keyframes popIn { 0% { transform: scale(0); } 70% { transform: scale(1.08); } 100% { transform: scale(1); } }
        @keyframes mergePulse { 0% { transform: scale(.6); } 55% { transform: scale(1.18); } 100% { transform: scale(1); } }
        @keyframes floatUp { 0% { opacity: 0; transform: translateY(6px); } 15% { opacity: 1; } 100% { opacity: 0; transform: translateY(-26px); } }
        @keyframes flicker { 0%,100% { opacity: 1; } 50% { opacity: .55; } }
        @media (prefers-reduced-motion: reduce) {
          .ember-tile { transition: none !important; animation: none !important; }
        }
      `}</style>

      <div style={{ width: "min(92vw, 420px)" }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 12 }}>
          <div>
            <div style={{ fontSize: 34, fontWeight: 800, letterSpacing: "0.06em", lineHeight: 1,
              background: theme.title, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              EMBER
            </div>
            <div style={{ fontSize: 11, color: "#7E88AC", marginTop: 6, letterSpacing: "0.04em" }}>
              {game.mode === "daily" ? `daily #${dailyNumber()} · same board for everyone` : "merge to white-hot · chain merges for ×4"}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, position: "relative" }}>
            {[["SCORE", game.score], ["BEST", game.best]].map(([label, val]) => (
              <div key={label} style={{ background: theme.chip, borderRadius: 10, padding: "7px 12px", textAlign: "center", minWidth: 62 }}>
                <div style={{ fontSize: 9, color: "#7E88AC", letterSpacing: "0.12em" }}>{label}</div>
                <div style={{ fontSize: 17, fontWeight: 800 }}>{val}</div>
              </div>
            ))}
            {pop && (
              <div key={pop.id} style={{
                position: "absolute", right: 4, top: -6, fontWeight: 800, fontSize: 15,
                color: theme.accent, animation: "floatUp 900ms ease-out forwards", pointerEvents: "none",
              }}>
                {pop.text}
              </div>
            )}
          </div>
        </div>

        <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>
          {[["classic", "Classic"], ["daily", `Daily #${dailyNumber()}`]].map(([key, label]) => (
            <button key={key} onClick={() => startGame(key)} style={{
              flex: 1, background: game.mode === key ? theme.accent : "transparent",
              border: `1px solid ${game.mode === key ? theme.accent : "#2A3352"}`,
              borderRadius: 8, padding: "8px 4px", cursor: "pointer",
              color: game.mode === key ? "#10131F" : "#7E88AC",
              fontFamily: "inherit", fontSize: 12, fontWeight: 800, letterSpacing: "0.04em",
            }}>
              {label}
            </button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
          {Object.entries(THEMES).map(([key, t]) => (
            <button key={key} onClick={() => setThemeKey(key)} style={{
              flex: 1, background: key === themeKey ? t.cell : "transparent",
              border: `1px solid ${key === themeKey ? t.accent : "#2A3352"}`,
              borderRadius: 8, padding: "6px 4px", cursor: "pointer",
              color: key === themeKey ? "#E8ECF8" : "#7E88AC",
              fontFamily: "inherit", fontSize: 11, fontWeight: 700, letterSpacing: "0.04em",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 5,
            }}>
              <span style={{ width: 10, height: 10, borderRadius: 5, background: t.accent, display: "inline-block" }} />
              {t.label}
              {t.pro && (
                <span style={{ fontSize: 8, background: t.accent, color: "#10131F", borderRadius: 4, padding: "1px 4px", fontWeight: 800 }}>
                  PRO
                </span>
              )}
            </button>
          ))}
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
          <div style={{ display: "flex", gap: 3, flex: 1 }}>
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} style={{
                flex: 1, height: 6, borderRadius: 3,
                background: i < heatSegs ? theme.accent : theme.cell,
                boxShadow: i < heatSegs ? `0 0 8px ${theme.accent}88` : "none",
                opacity: i < heatSegs ? 0.55 + (i / 9) * 0.45 : 1,
                transition: "background 200ms",
                animation: i < heatSegs && heatSegs >= 7 ? "flicker 800ms infinite" : "none",
              }} />
            ))}
          </div>
          <div style={{
            fontSize: 13, fontWeight: 800, minWidth: 34, textAlign: "right",
            color: mult >= 2 ? theme.accent : "#7E88AC",
          }}>
            ×{mult}
          </div>
        </div>

        <div onTouchStart={onTouchStart} onTouchEnd={onTouchEnd} style={{
          position: "relative", width: "100%", aspectRatio: "1 / 1",
          background: theme.board, borderRadius: 14, touchAction: "none",
          boxShadow: "inset 0 2px 10px rgba(0,0,0,.4)", transition: "background 300ms",
        }}>
          {Array.from({ length: SIZE * SIZE }).map((_, i) => (
            <div key={`bg-${i}`} style={{
              position: "absolute", borderRadius: 8, background: theme.cell,
              transition: "background 300ms",
              ...posStyle((i / SIZE) | 0, i % SIZE),
            }} />
          ))}

          {game.tiles.map(t => {
            const s = theme.tile(t.value);
            return (
              <div key={t.id} className="ember-tile" style={{
                position: "absolute", borderRadius: 8,
                display: "flex", alignItems: "center", justifyContent: "center",
                background: s.bg, color: s.fg, boxShadow: s.glow,
                fontWeight: 800,
                fontSize: t.value >= 1024 ? "clamp(16px, 5.4vw, 26px)" : t.value >= 128 ? "clamp(18px, 6.4vw, 30px)" : "clamp(20px, 7.4vw, 34px)",
                zIndex: t.dying ? 1 : 2,
                transition: "left 120ms ease-out, top 120ms ease-out, background 300ms",
                animation: t.isNew ? "popIn 160ms ease-out" : t.justMerged ? "mergePulse 180ms ease-out" : "none",
                ...posStyle(t.row, t.col),
              }}>
                {t.value}
              </div>
            );
          })}

          {(game.over || showWinOverlay) && (
            <div style={{
              position: "absolute", inset: 0, borderRadius: 14, zIndex: 5,
              background: "rgba(10,13,26,.86)", backdropFilter: "blur(2px)",
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12, padding: 16,
            }}>
              <div style={{ fontSize: 24, fontWeight: 800, color: showWinOverlay && !game.over ? theme.accent : "#E8ECF8" }}>
                {showWinOverlay && !game.over ? "White-hot! 2048" : "Out of moves"}
              </div>
              <div style={{
                background: theme.cell, borderRadius: 12, padding: "12px 18px",
                textAlign: "center", fontSize: 14, lineHeight: 1.7, whiteSpace: "pre-line",
                border: `1px solid ${theme.accent}55`,
              }}>
                {shareText()}
              </div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center" }}>
                <button onClick={share} style={btnStyle(theme.accent)}>
                  {copied ? "Copied ✓" : "Share result"}
                </button>
                {showWinOverlay && !game.over && (
                  <button onClick={() => commit({ ...stateRef.current, keepGoing: true })} style={btnStyle(theme.cell)}>
                    Keep going
                  </button>
                )}
                <button onClick={() => startGame(game.mode)} style={btnStyle(theme.cell)}>Play again</button>
              </div>
            </div>
          )}
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <button onClick={() => startGame(game.mode)} style={{ ...btnStyle(theme.cell), flex: 1 }}>New game</button>
          <button onClick={undo} disabled={!canUndo}
            style={{ ...btnStyle(theme.cell), flex: 1, opacity: canUndo ? 1 : 0.45 }}>
            Undo
          </button>
        </div>

        <div style={{ marginTop: 14, fontSize: 12, color: "#5C6688", textAlign: "center", lineHeight: 1.6 }}>
          Chain merges to feed the flame — points multiply up to ×4, one dry move resets it.
          Daily mode deals the same board to every player worldwide; share your result and compare.
        </div>
      </div>
    </div>
  );
}

const btnStyle = (bg) => ({
  background: bg,
  color: ["#ED6B3C", "#5FC7E8", "#E84FD0"].includes(bg) ? "#10131F" : "#E8ECF8",
  border: "none", borderRadius: 10,
  padding: "12px 18px", fontSize: 14, fontWeight: 700, cursor: "pointer",
  fontFamily: "inherit", letterSpacing: "0.02em",
});
